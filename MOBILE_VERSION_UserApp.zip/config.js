var server_domain = 'http://callmycab.in';
var secret_key = "My_key";
var wordpress = false;


